# MASTER XCLOUD v1.7.6

Versão de validação da atualização por cima da v1.7.5.

## Objetivo
- manter todas as funções da v1.7.5;
- manter o mesmo applicationId;
- manter a mesma assinatura release permanente;
- usar versionCode 16;
- usar versionName 1.7.6;
- confirmar que o Android oferece Atualizar em vez de exigir desinstalação.

Nenhuma mudança funcional foi feita nesta versão.
