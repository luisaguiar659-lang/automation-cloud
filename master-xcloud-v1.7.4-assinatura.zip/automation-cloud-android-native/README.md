# MASTER XCLOUD v1.7.4

Base: v1.7.3.

## Atualização
A tela de login foi ajustada para se adaptar melhor a celulares com tamanhos,
resoluções e densidades diferentes, preservando o restante da automação.

### Login responsivo
- login dentro de ScrollView;
- rolagem disponível em telas pequenas;
- teclado usa adjustResize e não cobre os campos/botão;
- logo reduz automaticamente em telas compactas;
- título, subtítulo, campos, espaçamentos e botão reduzem em telas menores;
- em telas largas/tablets o formulário não fica excessivamente esticado;
- campos continuam com largura útil e centralizada;
- email usa ação "Próximo" no teclado;
- senha usa ação "Concluir";
- status de login permanece visível abaixo do botão.

### Preservado
- credenciais criptografadas;
- login manual pelo botão ENTRAR;
- automação Ativar MAC + DNS;
- Editar (Reset) + DNS;
- Excluir MAC;
- painel WebView;
- resumo;
- logout;
- logs;
- refresh;
- demais fluxos da v1.7.3.

Versão: 1.7.4
versionCode: 14
