# Automation Cloud — Android nativo

Versão independente do AppMint.

## O que faz

O aplicativo usa `android.webkit.WebView` e JavaScript injetado para executar
o fluxo real no painel.

Fluxos:

1. Ativar MAC + DNS
2. Editar (Reset) + DNS
3. Excluir MAC

URLs configuradas:

- `https://panel.xtream.cloud/#/login`
- `https://panel-v2.xtream.cloud/dashboard/devices`
- `https://xtream.cloud/custom-playlist?device_key=<KEY>&type=xtream&mode=add`

## Segurança

- Email e senha ficam em `EncryptedSharedPreferences`.
- O app bloqueia navegação do WebView para hosts não autorizados.
- A playlist não é salva no histórico.
- O código não contém credenciais.

## Gerar o APK sem Android Studio

### Opção recomendada: GitHub Actions

1. Crie um repositório privado no GitHub.
2. Envie todo o conteúdo deste projeto para o repositório.
3. Abra a aba **Actions**.
4. Selecione **Build Android APK**.
5. Clique em **Run workflow**.
6. Quando terminar, abra a execução.
7. Em **Artifacts**, baixe `AutomationCloud-APK`.
8. Dentro do ZIP estará `AutomationCloud.apk`.

O workflow também executa automaticamente após push na branch `main`.

## Android Studio

Se preferir compilar localmente:

- JDK 17
- Android SDK 35
- Gradle 8.7

Depois:

```bash
gradle :app:assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Diagnóstico

O botão `VER PAINEL` mostra a WebView real. Se algum seletor do Xtream mudar,
o erro aparece no console e a página pode ser inspecionada visualmente.

Os scripts ficam em:

`MainActivity.java` → classe interna `JsScripts`.


## Reset tolerante

Na versão 1.1, `Editar (Reset) + DNS` trata `DEVICE_NOT_FOUND` como um estado válido.
Se a Device Key já tiver sido removida, o fluxo segue automaticamente para
`Add Device` e depois `Custom Playlist`.


## Login separado — versão 1.2

A primeira tela agora é exclusivamente de login.

- Email e senha aparecem somente na tela inicial.
- Após autenticação válida, o aplicativo abre a tela de automação.
- As credenciais ficam salvas em `EncryptedSharedPreferences`.
- Nas próximas aberturas, o aplicativo tenta autenticar automaticamente.
- A tela principal não pede email/senha novamente.
- O botão `SAIR` apaga credenciais, cookies e volta para a tela de login.
