# Automation Cloud — Android nativo

Versão independente do AppMint.

## O que faz

O aplicativo usa `android.webkit.WebView` e JavaScript injetado para executar
o fluxo real no painel.

Fluxos:

1. Ativar MAC + DNS
2. Editar (Reset) + DNS
3. Excluir MAC

URLs configuradas:

- `https://panel.xtream.cloud/#/login`
- `https://panel-v2.xtream.cloud/dashboard/devices`
- `https://xtream.cloud/custom-playlist?device_key=<KEY>&type=xtream&mode=add`

## Segurança

- Email e senha ficam em `EncryptedSharedPreferences`.
- O app bloqueia navegação do WebView para hosts não autorizados.
- A playlist não é salva no histórico.
- O código não contém credenciais.

## Gerar o APK sem Android Studio

### Opção recomendada: GitHub Actions

1. Crie um repositório privado no GitHub.
2. Envie todo o conteúdo deste projeto para o repositório.
3. Abra a aba **Actions**.
4. Selecione **Build Android APK**.
5. Clique em **Run workflow**.
6. Quando terminar, abra a execução.
7. Em **Artifacts**, baixe `AutomationCloud-APK`.
8. Dentro do ZIP estará `AutomationCloud.apk`.

O workflow também executa automaticamente após push na branch `main`.

## Android Studio

Se preferir compilar localmente:

- JDK 17
- Android SDK 35
- Gradle 8.7

Depois:

```bash
gradle :app:assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Diagnóstico

O botão `VER PAINEL` mostra a WebView real. Se algum seletor do Xtream mudar,
o erro aparece no console e a página pode ser inspecionada visualmente.

Os scripts ficam em:

`MainActivity.java` → classe interna `JsScripts`.


## Reset tolerante

Na versão 1.1, `Editar (Reset) + DNS` trata `DEVICE_NOT_FOUND` como um estado válido.
Se a Device Key já tiver sido removida, o fluxo segue automaticamente para
`Add Device` e depois `Custom Playlist`.


## Login separado — versão 1.2

A primeira tela agora é exclusivamente de login.

- Email e senha aparecem somente na tela inicial.
- Após autenticação válida, o aplicativo abre a tela de automação.
- As credenciais ficam salvas em `EncryptedSharedPreferences`.
- Nas próximas aberturas, o aplicativo tenta autenticar automaticamente.
- A tela principal não pede email/senha novamente.
- O botão `SAIR` apaga credenciais, cookies e volta para a tela de login.


## Rebranding — versão 1.3

Mudanças aplicadas:
- nome do aplicativo alterado para **MASTER XCLOUD**
- ícone/logo atualizado com a arte enviada
- tela inicial de login com logo centralizada
- tela de progresso simplificada:
  - por padrão mostra apenas mensagens amigáveis
  - URLs e códigos internos ficam ocultos
  - botão `DETALHES` ativa o modo técnico


## Identidade visual — versão 1.4

Aplicada a identidade MASTER XCLOUD em toda a interface:
- fundo preto/grafite
- destaques laranja e azul-ciano
- botão principal em gradiente
- cartões com bordas discretas
- inputs com visual premium
- cabeçalho com linha de brilho laranja → azul
- logo na tela principal
- área de status em cartão próprio
- status resumidos com cores da marca
- modo técnico preservado pelo botão DETALHES


## Hotfix — versão 1.4.1

Corrigida uma quebra de linha inválida em uma string Java do modo DETALHES,
que impedia a compilação da versão 1.4.


## MASTER XCLOUD 1.5

- Uma única mensagem de status por vez.
- Mensagens amigáveis: Ativando MAC, Subindo M3U, Repondo DNS, Excluindo MAC.
- Após sucesso, limpa Device Key/MAC e URL M3U/DNS automaticamente.
- Login persistente reforçado:
  - reaproveita sessão/cookies quando possível;
  - reloga automaticamente com credenciais criptografadas salvas;
  - mais seletores e maior tempo de espera;
  - retry automático na rota direta de login.


## MASTER XCLOUD 1.5.1

Hotfix de compilação:
- corrigida uma quebra de linha inválida em string Java do modo DETALHES;
- mantidas todas as melhorias da 1.5:
  - uma única mensagem de status por vez;
  - limpeza automática de MAC e M3U/DNS após sucesso;
  - login persistente reforçado.
