package com.automationcloud.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String PANEL_LOGIN =
            "https://panel.xtream.cloud/#/login";

    private static final String PANEL_DEVICES =
            "https://panel-v2.xtream.cloud/dashboard/devices";

    private static final String PLAYLIST_BASE =
            "https://xtream.cloud/custom-playlist";

    private static final Set<String> ALLOWED_HOSTS = new HashSet<>(Arrays.asList(
            "panel.xtream.cloud",
            "panel-v2.xtream.cloud",
            "xtream.cloud"
    ));

    private enum Flow {
        ACTIVATE,
        RESET,
        DELETE
    }

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private ScrollView consoleView;
    private LinearLayout progressList;

    private LinearLayout loginScreen;
    private LinearLayout appScreen;
    private TextView loginStatus;

    private EditText emailInput;
    private EditText passwordInput;
    private EditText deviceInput;
    private EditText playlistInput;
    private Spinner flowSpinner;

    private Button executeButton;
    private Button toggleBrowserButton;
    private Button loginButton;
    private Button logoutButton;
    private Button detailsButton;

    private Flow activeFlow = Flow.ACTIVATE;

    private boolean loginInjected = false;
    private boolean deviceInjected = false;
    private boolean deleteInjected = false;
    private boolean playlistInjected = false;
    private boolean resetDeleteCompleted = false;
    private boolean running = false;
    private boolean loginOnlyMode = false;
    private boolean authenticated = false;
    private boolean detailedLogs = false;

    private String currentDevice = "";
    private String currentPlaylist = "";

    private SharedPreferences securePrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        securePrefs = createSecurePreferences();
        buildUi();
        setupWebView();
        loadSavedCredentials();

        if (!emailInput.getText().toString().trim().isEmpty()
                && !passwordInput.getText().toString().isEmpty()) {
            showLoginScreen();
            loginStatus.setText("Entrando automaticamente...");
            authenticateOnly();
        } else {
            showLoginScreen();
        }
    }

    private SharedPreferences createSecurePreferences() {
        try {
            MasterKey key = new MasterKey.Builder(this)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            return EncryptedSharedPreferences.create(
                    this,
                    "automation_secure",
                    key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception error) {
            throw new RuntimeException("Falha ao inicializar armazenamento seguro.", error);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(
                settings.getUserAgentString() + " AutomationCloud/1.0"
        );

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AutomationBridge(), "AutomationBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request
            ) {
                String host = request.getUrl().getHost();

                if (host == null || !ALLOWED_HOSTS.contains(host)) {
                    addProgress(
                            "BLOQUEADO",
                            "Navegação externa bloqueada: " + host,
                            Color.rgb(255, 107, 107)
                    );
                    return true;
                }

                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                handlePageFinished(url);
            }
        });

        WebView.setWebContentsDebuggingEnabled(true);
    }


    private void buildUi() {
        int pad = dp(16);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(pad, dp(14), pad, dp(10));

        TextView title = new TextView(this);
        title.setText("MASTER XCLOUD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setTypeface(null, 1);
        title.setLetterSpacing(0.02f);

        topBar.addView(
                title,
                new LinearLayout.LayoutParams(0, dp(48), 1f)
        );

        toggleBrowserButton = new Button(this);
        toggleBrowserButton.setText("PAINEL");
        toggleBrowserButton.setTextSize(11);
        toggleBrowserButton.setTextColor(Color.WHITE);
        toggleBrowserButton.setBackgroundResource(getDrawableId("bg_secondary_button", "drawable"));
        toggleBrowserButton.setVisibility(View.GONE);
        toggleBrowserButton.setOnClickListener(v -> toggleBrowser());
        topBar.addView(toggleBrowserButton);

        detailsButton = new Button(this);
        detailsButton.setText("DETALHES");
        detailsButton.setTextSize(11);
        detailsButton.setTextColor(Color.WHITE);
        detailsButton.setBackgroundResource(getDrawableId("bg_secondary_button", "drawable"));
        detailsButton.setVisibility(View.GONE);
        detailsButton.setOnClickListener(v -> toggleDetails());
        topBar.addView(detailsButton);

        logoutButton = new Button(this);
        logoutButton.setText("SAIR");
        logoutButton.setTextSize(11);
        logoutButton.setTextColor(Color.WHITE);
        logoutButton.setBackgroundResource(getDrawableId("bg_secondary_button", "drawable"));
        logoutButton.setVisibility(View.GONE);
        logoutButton.setOnClickListener(v -> logout());
        topBar.addView(logoutButton);

        root.addView(topBar);

        View glowLine = new View(this);
        glowLine.setBackgroundResource(getDrawableId("bg_glow_line", "drawable"));
        root.addView(glowLine, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(3)
        ));

        // ---------- LOGIN SCREEN ----------
        loginScreen = new LinearLayout(this);
        loginScreen.setOrientation(LinearLayout.VERTICAL);
        loginScreen.setPadding(dp(22), dp(28), dp(22), dp(40));

        ImageView appLogo = new ImageView(this);
        appLogo.setImageResource(getDrawableId("logo_master_xcloud", "drawable"));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(156), dp(156));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        appLogo.setLayoutParams(logoParams);
        loginScreen.addView(appLogo);

        loginScreen.addView(space());

        TextView loginTitle = new TextView(this);
        loginTitle.setText("MASTER XCLOUD");
        loginTitle.setTextColor(Color.WHITE);
        loginTitle.setTextSize(28);
        loginTitle.setTypeface(null, 1);
        loginTitle.setGravity(Gravity.CENTER_HORIZONTAL);
        loginScreen.addView(loginTitle);

        TextView loginSubtitle = new TextView(this);
        loginSubtitle.setText("Faça login para acessar a automação.");
        loginSubtitle.setTextColor(Color.rgb(168, 179, 188));
        loginSubtitle.setTextSize(14);
        loginSubtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        loginSubtitle.setPadding(0, dp(8), 0, dp(28));
        loginScreen.addView(loginSubtitle);

        emailInput = field("Email", false);
        passwordInput = field("Senha", true);

        loginScreen.addView(emailInput);
        loginScreen.addView(space());
        loginScreen.addView(passwordInput);
        loginScreen.addView(space());

        loginButton = new Button(this);
        loginButton.setText("ENTRAR");
        loginButton.setTextSize(15);
        loginButton.setTypeface(null, 1);
        loginButton.setTextColor(Color.WHITE);
        loginButton.setBackgroundResource(getDrawableId("bg_login_gradient", "drawable"));
        loginButton.setOnClickListener(v -> authenticateOnly());
        loginScreen.addView(loginButton, matchHeight(dp(56)));

        loginStatus = new TextView(this);
        loginStatus.setText("");
        loginStatus.setTextColor(Color.rgb(0, 184, 255));
        loginStatus.setTextSize(13);
        loginStatus.setPadding(0, dp(18), 0, 0);
        loginScreen.addView(loginStatus);

        root.addView(
                loginScreen,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        // ---------- MAIN APP SCREEN ----------
        appScreen = new LinearLayout(this);
        appScreen.setOrientation(LinearLayout.VERTICAL);
        appScreen.setVisibility(View.GONE);

        consoleView = new ScrollView(this);
        consoleView.setFillViewport(true);

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(20), dp(18), dp(40));

        LinearLayout brandCard = new LinearLayout(this);
        brandCard.setOrientation(LinearLayout.HORIZONTAL);
        brandCard.setGravity(Gravity.CENTER_VERTICAL);
        brandCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        brandCard.setBackgroundResource(getDrawableId("bg_card", "drawable"));

        ImageView miniLogo = new ImageView(this);
        miniLogo.setImageResource(getDrawableId("logo_master_xcloud", "drawable"));
        brandCard.addView(miniLogo, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(12), 0, 0, 0);

        TextView brandName = new TextView(this);
        brandName.setText("MASTER XCLOUD");
        brandName.setTextColor(Color.WHITE);
        brandName.setTextSize(19);
        brandName.setTypeface(null, 1);

        TextView brandStatus = new TextView(this);
        brandStatus.setText("Automação conectada");
        brandStatus.setTextColor(Color.rgb(0, 184, 255));
        brandStatus.setTextSize(12);

        brandText.addView(brandName);
        brandText.addView(brandStatus);
        brandCard.addView(brandText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        form.addView(brandCard);
        form.addView(sectionGap());

        form.addView(sectionTitle("PAINEL DE AUTOMAÇÃO"));

        flowSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{
                        "Ativar MAC + DNS",
                        "Editar (Reset) + DNS",
                        "Excluir MAC"
                }
        );
        flowSpinner.setAdapter(adapter);
        flowSpinner.setBackgroundResource(getDrawableId("bg_input", "drawable"));
        form.addView(flowSpinner, matchHeight(dp(54)));

        form.addView(space());

        deviceInput = field("Device Key / MAC", false);
        form.addView(deviceInput);

        form.addView(space());

        playlistInput = field("URL da playlist / DNS", false);
        playlistInput.setMinLines(2);
        playlistInput.setGravity(Gravity.TOP);
        form.addView(playlistInput);

        form.addView(space());

        executeButton = new Button(this);
        executeButton.setText("EXECUTAR");
        executeButton.setTextSize(15);
        executeButton.setTypeface(null, 1);
        executeButton.setTextColor(Color.WHITE);
        executeButton.setBackgroundResource(getDrawableId("bg_action_gradient", "drawable"));
        executeButton.setOnClickListener(v -> startFlow());
        form.addView(executeButton, matchHeight(dp(56)));

        form.addView(sectionGap());
        form.addView(sectionTitle("STATUS DA AUTOMAÇÃO"));

        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(14), dp(10), dp(14), dp(10));
        statusCard.setBackgroundResource(getDrawableId("bg_card", "drawable"));

        progressList = new LinearLayout(this);
        progressList.setOrientation(LinearLayout.VERTICAL);
        statusCard.addView(progressList);

        form.addView(statusCard);

        addProgress(
                "PRONTO",
                "Pronto para iniciar a automação.",
                Color.rgb(136, 148, 139)
        );

        consoleView.addView(form);

        appScreen.addView(
                consoleView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        webView = new WebView(this);
        webView.setVisibility(View.GONE);

        appScreen.addView(
                webView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        root.addView(
                appScreen,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        setContentView(root);
    }

    private TextView sectionTitle(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(255, 156, 0));
        view.setTextSize(12);
        view.setTypeface(null, 1);
        view.setLetterSpacing(0.08f);
        view.setPadding(0, 0, 0, dp(12));
        return view;
    }

    private EditText field(String hint, boolean password) {
        EditText view = new EditText(this);
        view.setHint(hint);
        view.setHintTextColor(Color.rgb(120, 132, 142));
        view.setTextColor(Color.WHITE);
        view.setTextSize(15);
        view.setPadding(dp(16), dp(14), dp(16), dp(14));
        view.setBackgroundResource(getDrawableId("bg_input", "drawable"));

        if (password) {
            view.setInputType(
                    InputType.TYPE_CLASS_TEXT |
                    InputType.TYPE_TEXT_VARIATION_PASSWORD
            );
        }

        return view;
    }

    private View space() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(12)));
        return v;
    }

    private View sectionGap() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(28)));
        return v;
    }

    private LinearLayout.LayoutParams matchHeight(int height) {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                height
        );
    }


    private void showLoginScreen() {
        authenticated = false;
        loginScreen.setVisibility(View.VISIBLE);
        appScreen.setVisibility(View.GONE);
        toggleBrowserButton.setVisibility(View.GONE);
        detailsButton.setVisibility(View.GONE);
        logoutButton.setVisibility(View.GONE);
    }

    private void showAppScreen() {
        authenticated = true;
        loginOnlyMode = false;
        running = false;

        loginScreen.setVisibility(View.GONE);
        appScreen.setVisibility(View.VISIBLE);
        consoleView.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);

        toggleBrowserButton.setVisibility(View.VISIBLE);
        detailsButton.setVisibility(View.VISIBLE);
        logoutButton.setVisibility(View.VISIBLE);

        loginStatus.setText("");
        loginButton.setEnabled(true);
        loginButton.setText("ENTRAR");
    }

    private void authenticateOnly() {
        if (loginOnlyMode) return;

        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            toast("Informe email e senha.");
            return;
        }

        saveCredentials();

        loginOnlyMode = true;
        running = true;
        authenticated = false;
        loginInjected = false;

        loginButton.setEnabled(false);
        loginButton.setText("ENTRANDO...");
        loginStatus.setText("Conectando ao painel...");

        webView.loadUrl(PANEL_LOGIN);
    }

    private void logout() {
        running = false;
        authenticated = false;
        loginOnlyMode = false;

        securePrefs.edit().clear().apply();
        emailInput.setText("");
        passwordInput.setText("");

        webView.clearHistory();
        webView.clearCache(true);

        android.webkit.CookieManager.getInstance().removeAllCookies(null);
        android.webkit.CookieManager.getInstance().flush();

        detailedLogs = false;
        if (detailsButton != null) detailsButton.setText("DETALHES");
        showLoginScreen();
        loginStatus.setText("Sessão encerrada.");
    }


    private void toggleDetails() {
        detailedLogs = !detailedLogs;
        detailsButton.setText(detailedLogs ? "RESUMO" : "DETALHES");
        toast(detailedLogs ? "Modo detalhado ativado." : "Modo resumido ativado.");
    }

    private int getDrawableId(String name, String type) {
        return getResources().getIdentifier(name, type, getPackageName());
    }

    private void loadSavedCredentials() {
        emailInput.setText(securePrefs.getString("email", ""));
        passwordInput.setText(securePrefs.getString("password", ""));
    }

    private void saveCredentials() {
        securePrefs.edit()
                .putString("email", emailInput.getText().toString().trim())
                .putString("password", passwordInput.getText().toString())
                .apply();
    }

    private void startFlow() {
        if (running) return;

        if (!authenticated) {
            showLoginScreen();
            toast("Faça login primeiro.");
            return;
        }

        String device = deviceInput.getText().toString().trim().toUpperCase();
        String playlist = playlistInput.getText().toString().trim();

        if (!device.matches("^[A-Z0-9_-]{4,32}$")) {
            toast("Device Key inválida.");
            return;
        }

        int selected = flowSpinner.getSelectedItemPosition();
        activeFlow = selected == 1
                ? Flow.RESET
                : selected == 2
                    ? Flow.DELETE
                    : Flow.ACTIVATE;

        if (activeFlow != Flow.DELETE &&
                !(playlist.startsWith("http://") ||
                  playlist.startsWith("https://"))) {
            toast("Informe uma URL válida da playlist.");
            return;
        }

        currentDevice = device;
        currentPlaylist = playlist;

        loginInjected = false;
        deviceInjected = false;
        deleteInjected = false;
        playlistInjected = false;
        resetDeleteCompleted = false;
        running = true;

        progressList.removeAllViews();

        executeButton.setEnabled(false);
        executeButton.setText("PROCESSANDO...");

        addProgress(
                "INÍCIO",
                flowLabel(activeFlow),
                Color.rgb(255, 193, 7)
        );

        webView.loadUrl(
                PANEL_DEVICES + "?t=" + System.currentTimeMillis()
        );
    }

    private void handlePageFinished(String url) {
        if (!running || url == null) return;

        String lower = url.toLowerCase();

        if (loginOnlyMode) {
            if ((lower.contains("/login") || lower.contains("#/login"))
                    && !loginInjected) {
                loginInjected = true;

                String script = JsScripts.login(
                        emailInput.getText().toString().trim(),
                        passwordInput.getText().toString()
                );

                webView.evaluateJavascript(script, null);
                loginStatus.setText("Autenticando...");

                handler.postDelayed(() -> {
                    if (loginOnlyMode && running) {
                        String currentUrl = webView.getUrl();
                        if (currentUrl != null
                                && !currentUrl.toLowerCase().contains("/login")
                                && !currentUrl.toLowerCase().contains("#/login")) {
                            showAppScreen();
                        }
                    }
                }, 4500);

                return;
            }

            // O painel principal indica que o login foi aceito.
            if (lower.contains("/dashboard")
                    && !lower.contains("/login")
                    && !lower.contains("#/login")) {
                showAppScreen();
                return;
            }
        }

        if (!loginOnlyMode) {
            addProgress(
                    "PÁGINA",
                    url,
                    Color.rgb(136, 148, 139)
            );
        }

        if (lower.contains("panel-v2.xtream.cloud") &&
                lower.contains("/dashboard/devices")) {
            handleDevicesPage();
            return;
        }

        if (lower.contains("xtream.cloud/custom-playlist") &&
                !playlistInjected) {
            playlistInjected = true;

            webView.evaluateJavascript(
                    JsScripts.addPlaylist(
                            currentDevice,
                            currentPlaylist
                    ),
                    null
            );
        }
    }

    private void handleDevicesPage() {
        if (activeFlow == Flow.DELETE) {
            if (deleteInjected) return;

            deleteInjected = true;
            webView.evaluateJavascript(
                    JsScripts.deleteDevice(currentDevice),
                    null
            );
            return;
        }

        if (activeFlow == Flow.RESET && !resetDeleteCompleted) {
            if (deleteInjected) return;

            deleteInjected = true;
            webView.evaluateJavascript(
                    JsScripts.deleteDevice(currentDevice),
                    null
            );
            return;
        }

        if (!deviceInjected) {
            deviceInjected = true;
            webView.evaluateJavascript(
                    JsScripts.addDevice(currentDevice),
                    null
            );
        }
    }

    private void onAutomationMessage(String raw) {
        runOnUiThread(() -> {
            try {
                JSONObject obj = new JSONObject(raw);

                String type = obj.optString("type", "progress");
                String code = obj.optString("code", "EVENT");
                String message = obj.optString("message", "");

                int color = Color.rgb(255, 193, 7);

                if ("success".equals(type)) {
                    color = Color.rgb(183, 255, 60);
                } else if ("error".equals(type)) {
                    color = Color.rgb(255, 107, 107);
                }

                if (loginOnlyMode) {
                    if ("error".equals(type)) {
                        loginOnlyMode = false;
                        running = false;
                        loginButton.setEnabled(true);
                        loginButton.setText("ENTRAR");
                        loginStatus.setText(message);
                    } else {
                        loginStatus.setText(message);
                    }
                    return;
                }

                addProgress(code, message, color);

                if ("DEVICE_ADDED".equals(code)) {
                    webView.loadUrl(
                            PLAYLIST_BASE
                                    + "?device_key=" + android.net.Uri.encode(currentDevice)
                                    + "&type=xtream&mode=add"
                    );
                    return;
                }

                if ("DEVICE_DELETED".equals(code)) {
                    if (activeFlow == Flow.DELETE) {
                        finishFlow("Dispositivo removido.");
                        return;
                    }

                    if (activeFlow == Flow.RESET) {
                        resetDeleteCompleted = true;
                        deleteInjected = false;
                        deviceInjected = false;

                        webView.loadUrl(
                                PANEL_DEVICES + "?t=" + System.currentTimeMillis()
                        );
                        return;
                    }
                }

                // No fluxo Reset, a chave pode já ter sido removida antes.
                // Nesse caso, seguimos direto para Add Device + Custom Playlist.
                if ("DEVICE_NOT_FOUND".equals(code) && activeFlow == Flow.RESET) {
                    addProgress(
                            "RESET_CONTINUE",
                            "Dispositivo não existe; seguindo direto para novo cadastro.",
                            Color.rgb(183, 255, 60)
                    );

                    resetDeleteCompleted = true;
                    deleteInjected = false;
                    deviceInjected = false;

                    webView.loadUrl(
                            PANEL_DEVICES + "?t=" + System.currentTimeMillis()
                    );
                    return;
                }

                if ("PLAYLIST_ADDED".equals(code)) {
                    finishFlow(
                            activeFlow == Flow.RESET
                                    ? "Editar (Reset) + DNS concluído."
                                    : "Ativar MAC + DNS concluído."
                    );
                    return;
                }

                if ("error".equals(type)) {
                    showBrowser(true);
                    stopBusyOnly();
                }

            } catch (Exception error) {
                addProgress(
                        "ERRO",
                        "Mensagem inválida da WebView.",
                        Color.rgb(255, 107, 107)
                );
            }
        });
    }

    private void finishFlow(String message) {
        addProgress(
                "CONCLUÍDO",
                message,
                Color.rgb(183, 255, 60)
        );
        running = false;
        executeButton.setEnabled(true);
        executeButton.setText("EXECUTAR");
    }

    private void stopBusyOnly() {
        running = false;
        executeButton.setEnabled(true);
        executeButton.setText("EXECUTAR");
    }

    private void toggleBrowser() {
        showBrowser(webView.getVisibility() != View.VISIBLE);
    }

    private void showBrowser(boolean show) {
        webView.setVisibility(show ? View.VISIBLE : View.GONE);
        consoleView.setVisibility(show ? View.GONE : View.VISIBLE);
        toggleBrowserButton.setText(show ? "VOLTAR" : "PAINEL");
    }

    private void addProgress(String code, String message, int color) {
        if (!detailedLogs && "PÁGINA".equals(code)) {
            return;
        }

        TextView line = new TextView(this);

        String displayText;
        if (detailedLogs) {
            displayText = "● " + message + "\n   " + code;
        } else {
            displayText = "● " + message;
        }

        int displayColor = color;

        // Identidade MASTER XCLOUD:
        // progresso = laranja, sucesso = azul/ciano, erro = vermelho.
        if (code.contains("CONCLU") ||
                code.contains("ADDED") ||
                code.contains("DELETED") ||
                code.contains("CONTINUE")) {
            displayColor = Color.rgb(0, 184, 255);
        } else if (code.contains("ERROR") ||
                code.contains("NOT_FOUND") ||
                code.contains("TIMEOUT")) {
            displayColor = Color.rgb(255, 92, 92);
        } else if (!"PRONTO".equals(code)) {
            displayColor = Color.rgb(255, 166, 0);
        }

        line.setText(displayText);
        line.setTextColor(displayColor);
        line.setTextSize(15);
        line.setPadding(0, dp(8), 0, dp(8));

        progressList.addView(line);

        if (consoleView != null) {
            consoleView.post(() ->
                    consoleView.fullScroll(View.FOCUS_DOWN)
            );
        }
    }

    private String flowLabel(Flow flow) {
        switch (flow) {
            case RESET:
                return "Editar (Reset) + DNS";
            case DELETE:
                return "Excluir MAC";
            default:
                return "Ativar MAC + DNS";
        }
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE) {
            showBrowser(false);
            return;
        }

        super.onBackPressed();
    }

    public class AutomationBridge {
        @JavascriptInterface
        public void postMessage(String message) {
            onAutomationMessage(message);
        }
    }

    private static class JsScripts {

        private static String quote(String value) {
            return JSONObject.quote(value);
        }

        static String login(String email, String password) {
            return "(function(){"
                    + "const EMAIL=" + quote(email) + ";"
                    + "const PASSWORD=" + quote(password) + ";"
                    + helperFunctions()
                    + "let attempts=0;"
                    + "const timer=setInterval(()=>{"
                    + "attempts++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const emailInput=inputs.find(i=>i.type==='email')"
                    + "||inputs.find(i=>/email|e-mail/i.test(i.placeholder||''))"
                    + "||inputs[0];"
                    + "const passInput=inputs.find(i=>i.type==='password')"
                    + "||inputs.find(i=>/password|senha/i.test(i.placeholder||''));"
                    + "if(!emailInput||!passInput){"
                    + "if(attempts>=30){clearInterval(timer);"
                    + "post('error','LOGIN_FIELDS_NOT_FOUND','Campos de login não encontrados.');}"
                    + "return;}"
                    + "clearInterval(timer);"
                    + "post('progress','LOGIN_FILL','Autenticando no painel...');"
                    + "setReactInput(emailInput,EMAIL);"
                    + "setReactInput(passInput,PASSWORD);"
                    + "const form=passInput.closest('form')||emailInput.closest('form');"
                    + "const submit=(form&&form.querySelector('button[type=\"submit\"]'))"
                    + "||[...document.querySelectorAll('button')].find(b=>"
                    + "/login|entrar|sign in/i.test((b.textContent||'').trim()));"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(submit){clickReal(submit);}"
                    + "else if(form){form.submit();}"
                    + "post('progress','LOGIN_SUBMITTED','Login enviado.');"
                    + "},500);"
                    + "})();true;";
        }

        static String addDevice(String deviceKey) {
            return "(function(){"
                    + "const MAC=" + quote(deviceKey) + ";"
                    + helperFunctions()
                    + "function findAdd(){"
                    + "const buttons=[...document.querySelectorAll('button')];"
                    + "let btn=buttons.find(b=>{"
                    + "const c=String(b.className||'');"
                    + "const t=(b.textContent||'').toLowerCase().trim();"
                    + "return c.includes('bg-primary')&&c.includes('w-full')"
                    + "&&(t.includes('add')||t.includes('novo'));});"
                    + "if(btn)return btn;"
                    + "btn=buttons.find(b=>{const c=String(b.className||'');"
                    + "return c.includes('bg-primary')&&c.includes('w-full');});"
                    + "if(btn)return btn;"
                    + "const plus=document.querySelector('svg.lucide-plus');"
                    + "if(plus)return plus.closest('button');"
                    + "return buttons.find(b=>{"
                    + "const t=(b.textContent||'').toLowerCase().trim();"
                    + "return (t.includes('add')&&t.includes('device'))"
                    + "||t==='add'||t.includes('adicionar dispositivo');})||null;}"
                    + "const add=findAdd();"
                    + "if(!add){post('error','ADD_DEVICE_BUTTON_NOT_FOUND','Botão Add Device não encontrado.');return;}"
                    + "post('progress','OPEN_DEVICE_DIALOG','Abrindo cadastro do dispositivo...');"
                    + "clickReal(add);"
                    + "let attempts=0;"
                    + "const timer=setInterval(()=>{"
                    + "attempts++;"
                    + "const dialog=document.querySelector('[role=\"dialog\"]');"
                    + "if(!dialog&&(attempts===4||attempts===8)){const r=findAdd();if(r)clickReal(r);}"
                    + "if(!dialog){if(attempts>=20){clearInterval(timer);"
                    + "post('error','DEVICE_DIALOG_TIMEOUT','O modal de cadastro não abriu.');}return;}"
                    + "clearInterval(timer);"
                    + "post('progress','DEVICE_DIALOG_OPEN','Cadastro aberto.');"
                    + "const inputs=[...dialog.querySelectorAll('input')];"
                    + "let keyInput=inputs.find(i=>{"
                    + "if(['radio','checkbox','hidden'].includes(i.type))return false;"
                    + "const p=(i.placeholder||'').toLowerCase();"
                    + "return p.includes('device')||p.includes('key')||p.includes('mac')"
                    + "||p.includes('codigo')||p.includes('código');});"
                    + "keyInput=keyInput||inputs.find(i=>!['radio','checkbox','hidden'].includes(i.type));"
                    + "if(!keyInput){post('error','DEVICE_KEY_INPUT_NOT_FOUND','Campo Device Key não encontrado.');return;}"
                    + "setReactInput(keyInput,MAC);keyInput.blur();"
                    + "post('progress','DEVICE_KEY_FILLED','Device Key preenchida.');"
                    + "setTimeout(()=>{"
                    + "const form=dialog.querySelector('form');"
                    + "let submit=form&&form.querySelector('button[type=\"submit\"]');"
                    + "if(!submit){submit=[...dialog.querySelectorAll('button')].reverse().find(b=>{"
                    + "const t=(b.textContent||'').toLowerCase().trim();"
                    + "return t&&!t.includes('cancel')&&!t.includes('voltar');});}"
                    + "post('progress','DEVICE_SAVING','Salvando dispositivo...');"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(submit){clickReal(submit);}"
                    + "else if(form){form.submit();}"
                    + "else{post('error','DEVICE_SAVE_NOT_FOUND','Botão de salvar não encontrado.');return;}"
                    + "let wait=0;"
                    + "const close=setInterval(()=>{wait++;"
                    + "const open=document.querySelector('[role=\"dialog\"]');"
                    + "if(!open||wait>=30){clearInterval(close);"
                    + "post('success','DEVICE_ADDED',open?'Cadastro enviado.':'Dispositivo cadastrado.');}"
                    + "},500);"
                    + "},1200);"
                    + "},500);"
                    + "})();true;";
        }

        static String addPlaylist(String deviceKey, String playlistUrl) {
            return "(function(){"
                    + "const MAC=" + quote(deviceKey) + ";"
                    + "const URL_LISTA=" + quote(playlistUrl) + ";"
                    + helperFunctions()
                    + "let attempts=0;"
                    + "const timer=setInterval(()=>{attempts++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const urlInput=inputs.find(i=>{"
                    + "const p=(i.placeholder||'').toLowerCase();"
                    + "const a=i.getAttribute('aria-label')||'';"
                    + "return p.includes('http')||p.includes('url')||p.includes('link')"
                    + "||p.includes('playlist')||/url|playlist/i.test(a);});"
                    + "if(!urlInput){if(attempts>=30){clearInterval(timer);"
                    + "post('error','PLAYLIST_URL_INPUT_NOT_FOUND','Campo da URL não encontrado.');}"
                    + "return;}"
                    + "clearInterval(timer);"
                    + "post('progress','PLAYLIST_FILL','Enviando lista...');"
                    + "urlInput.focus();setReactInput(urlInput,URL_LISTA);urlInput.blur();"
                    + "setTimeout(()=>{"
                    + "const form=urlInput.closest('form');"
                    + "const buttons=[...document.querySelectorAll('button')];"
                    + "const save=(form&&form.querySelector('button[type=\"submit\"]'))"
                    + "||buttons.find(b=>{const t=(b.textContent||'').toLowerCase();"
                    + "return t.includes('save')||t.includes('add')||t.includes('salvar');});"
                    + "if(form&&typeof form.requestSubmit==='function'){form.requestSubmit();}"
                    + "else if(save){clickReal(save);}"
                    + "else if(form){form.submit();}"
                    + "else{post('error','PLAYLIST_SAVE_NOT_FOUND','Botão Save não encontrado.');return;}"
                    + "setTimeout(()=>{"
                    + "const body=(document.body.innerText||'').toLowerCase();"
                    + "const bad=body.includes('invalid')||body.includes('failed')"
                    + "||body.includes('error')||body.includes('required');"
                    + "if(bad){post('error','PLAYLIST_VISIBLE_ERROR','A página exibiu um erro.');}"
                    + "else{post('success','PLAYLIST_ADDED','Lista adicionada com sucesso.');}"
                    + "},2500);"
                    + "},900);"
                    + "},500);"
                    + "})();true;";
        }

        static String deleteDevice(String deviceKey) {
            return "(function(){"
                    + "const MAC=" + quote(deviceKey) + ";"
                    + helperFunctions()
                    + "function findRow(){return [...document.querySelectorAll('tr')].find(r=>"
                    + "(r.innerText||'').toUpperCase().includes(MAC.toUpperCase()));}"
                    + "function menuButton(row){"
                    + "const icon=row.querySelector('svg.lucide-ellipsis')"
                    + "||row.querySelector('svg[class*=\"ellipsis\"]');"
                    + "return icon?icon.closest('button'):null;}"
                    + "function action(words){"
                    + "const els=[...document.querySelectorAll('[role=\"menuitem\"]'),"
                    + "...document.querySelectorAll('button')];"
                    + "return els.find(e=>{const t=(e.textContent||'').trim().toLowerCase();"
                    + "return t&&t.length<80&&words.some(w=>t.includes(w));})||null;}"
                    + "function confirmDialog(){"
                    + "const ds=[...document.querySelectorAll('[role=\"dialog\"]')];"
                    + "const d=ds[ds.length-1];if(!d)return false;"
                    + "const b=[...d.querySelectorAll('button')].find(x=>{"
                    + "const t=(x.textContent||'').trim().toLowerCase();"
                    + "return t&&!t.includes('cancel')&&!t.includes('não')"
                    + "&&!t.includes('nao')&&t!=='no';});"
                    + "if(!b)return false;clickReal(b);return true;}"
                    + "post('progress','DELETE_SEARCH','Procurando dispositivo...');"
                    + "const sb=[...document.querySelectorAll('button')].find(b=>{"
                    + "const t=(b.textContent||'').trim().toLowerCase();"
                    + "return t==='search'||t==='pesquisar';});"
                    + "if(sb)clickReal(sb);"
                    + "let attempts=0;"
                    + "const timer=setInterval(()=>{attempts++;"
                    + "const inputs=[...document.querySelectorAll('input')];"
                    + "const search=inputs.find(i=>i.type==='search')"
                    + "||inputs.find(i=>/search|busca|filtr/i.test(i.placeholder||''))"
                    + "||inputs.find(i=>i.offsetParent!==null&&(i.type==='text'||!i.type));"
                    + "if(!search){if(attempts>=20){clearInterval(timer);"
                    + "post('error','SEARCH_INPUT_NOT_FOUND','Campo de pesquisa não encontrado.');}"
                    + "return;}"
                    + "clearInterval(timer);setReactInput(search,MAC);"
                    + "setTimeout(()=>{"
                    + "const row=findRow();"
                    + "if(!row){post('error','DEVICE_NOT_FOUND','Dispositivo não encontrado.');return;}"
                    + "const menu=menuButton(row);"
                    + "if(!menu){post('error','DEVICE_MENU_NOT_FOUND','Menu não encontrado.');return;}"
                    + "clickReal(menu);"
                    + "setTimeout(()=>{"
                    + "const deact=action(['deactivate','desativar','disable','inactiv']);"
                    + "const del0=action(['delete','excluir','deletar','remove','apagar','trash','lixeira']);"
                    + "if(deact){"
                    + "post('progress','DEACTIVATING','Desativando no painel...');"
                    + "clickReal(deact);"
                    + "setTimeout(()=>{confirmDialog();"
                    + "setTimeout(()=>{"
                    + "const row2=findRow();"
                    + "if(!row2){post('success','DEVICE_DELETED','Dispositivo removido.');return;}"
                    + "const menu2=menuButton(row2);"
                    + "if(!menu2){post('error','SECOND_MENU_NOT_FOUND','Não foi possível reabrir o menu.');return;}"
                    + "clickReal(menu2);"
                    + "setTimeout(()=>{"
                    + "const del=action(['delete','excluir','deletar','remove','apagar','trash','lixeira']);"
                    + "if(!del){post('error','DELETE_ACTION_NOT_FOUND','Ação Delete não encontrada.');return;}"
                    + "post('progress','DELETING','Removendo dispositivo...');"
                    + "clickReal(del);"
                    + "setTimeout(()=>{confirmDialog();"
                    + "setTimeout(()=>post('success','DEVICE_DELETED','Dispositivo removido.'),1400);"
                    + "},900);"
                    + "},1400);"
                    + "},2400);"
                    + "},900);"
                    + "return;"
                    + "}"
                    + "if(del0){"
                    + "post('progress','DELETING','Removendo dispositivo...');"
                    + "clickReal(del0);"
                    + "setTimeout(()=>{confirmDialog();"
                    + "setTimeout(()=>post('success','DEVICE_DELETED','Dispositivo removido.'),1400);"
                    + "},900);"
                    + "return;"
                    + "}"
                    + "post('error','DELETE_ACTION_NOT_FOUND','Deactivate/Delete não encontrado.');"
                    + "},1200);"
                    + "},800);"
                    + "},500);"
                    + "})();true;";
        }

        private static String helperFunctions() {
            return ""
                    + "function post(type,code,message){"
                    + "AutomationBridge.postMessage(JSON.stringify({type,code,message}));}"
                    + "function clickReal(button){"
                    + "try{button.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true}));"
                    + "button.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true}));}"
                    + "catch(e){}button.click();}"
                    + "function setReactInput(input,value){"
                    + "const own=Object.getOwnPropertyDescriptor(input,'value');"
                    + "const proto=Object.getPrototypeOf(input);"
                    + "const pd=Object.getOwnPropertyDescriptor(proto,'value');"
                    + "if(pd&&pd.set&&(!own||own.set!==pd.set)){pd.set.call(input,value);}"
                    + "else if(own&&own.set){own.set.call(input,value);}"
                    + "else{input.value=value;}"
                    + "input.dispatchEvent(new Event('input',{bubbles:true}));"
                    + "input.dispatchEvent(new Event('change',{bubbles:true}));"
                    + "if(input._valueTracker){input._valueTracker.setValue('');"
                    + "input.dispatchEvent(new Event('input',{bubbles:true}));}"
                    + "}";
        }
    }
}
