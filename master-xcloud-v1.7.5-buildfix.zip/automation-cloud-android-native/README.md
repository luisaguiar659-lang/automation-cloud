# MASTER XCLOUD v1.7.5

Base: v1.7.4 assinada.

## Interface responsiva completa

A v1.7.5 adapta toda a interface ao tamanho e densidade do aparelho, não somente
a tela de login.

### O que se adapta
- barra superior;
- título;
- botões PAINEL / RESUMO / SAIR;
- logo;
- tela de login;
- formulário principal;
- card de identificação;
- campos;
- seletor de fluxo;
- campo de playlist;
- botão EXECUTAR;
- card de status;
- margens e espaçamentos;
- WebView do painel.

### Faixas tratadas
- telas muito pequenas;
- celulares compactos;
- celulares médios;
- telas grandes;
- tablets.

Em telas pequenas, fontes, margens, logos e alturas diminuem para evitar cortes.
Em telas grandes, o conteúdo recebe largura útil máxima para não ficar esticado.

A tela de login permanece rolável e o teclado usa adjustResize.

### WebView
O painel usa wide viewport + overview mode para se adaptar melhor à largura
disponível do aparelho.

### Preservado
- automação da v1.7.4;
- credenciais criptografadas;
- histórico;
- resumo;
- login/logout;
- refresh;
- assinatura release permanente;
- mesmos 4 Repository Secrets do MASTER XCLOUD.

Versão: 1.7.5
versionCode: 15
