# Automation Cloud — Android nativo

Versão independente do AppMint.

## O que faz

O aplicativo usa `android.webkit.WebView` e JavaScript injetado para executar
o fluxo real no painel.

Fluxos:

1. Ativar MAC + DNS
2. Editar (Reset) + DNS
3. Excluir MAC

URLs configuradas:

- `https://panel.xtream.cloud/#/login`
- `https://panel-v2.xtream.cloud/dashboard/devices`
- `https://xtream.cloud/custom-playlist?device_key=<KEY>&type=xtream&mode=add`

## Segurança

- Email e senha ficam em `EncryptedSharedPreferences`.
- O app bloqueia navegação do WebView para hosts não autorizados.
- A playlist não é salva no histórico.
- O código não contém credenciais.

## Gerar o APK sem Android Studio

### Opção recomendada: GitHub Actions

1. Crie um repositório privado no GitHub.
2. Envie todo o conteúdo deste projeto para o repositório.
3. Abra a aba **Actions**.
4. Selecione **Build Android APK**.
5. Clique em **Run workflow**.
6. Quando terminar, abra a execução.
7. Em **Artifacts**, baixe `AutomationCloud-APK`.
8. Dentro do ZIP estará `AutomationCloud.apk`.

O workflow também executa automaticamente após push na branch `main`.

## Android Studio

Se preferir compilar localmente:

- JDK 17
- Android SDK 35
- Gradle 8.7

Depois:

```bash
gradle :app:assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Diagnóstico

O botão `VER PAINEL` mostra a WebView real. Se algum seletor do Xtream mudar,
o erro aparece no console e a página pode ser inspecionada visualmente.

Os scripts ficam em:

`MainActivity.java` → classe interna `JsScripts`.


## Reset tolerante

Na versão 1.1, `Editar (Reset) + DNS` trata `DEVICE_NOT_FOUND` como um estado válido.
Se a Device Key já tiver sido removida, o fluxo segue automaticamente para
`Add Device` e depois `Custom Playlist`.


## Login separado — versão 1.2

A primeira tela agora é exclusivamente de login.

- Email e senha aparecem somente na tela inicial.
- Após autenticação válida, o aplicativo abre a tela de automação.
- As credenciais ficam salvas em `EncryptedSharedPreferences`.
- Nas próximas aberturas, o aplicativo tenta autenticar automaticamente.
- A tela principal não pede email/senha novamente.
- O botão `SAIR` apaga credenciais, cookies e volta para a tela de login.


## Rebranding — versão 1.3

Mudanças aplicadas:
- nome do aplicativo alterado para **MASTER XCLOUD**
- ícone/logo atualizado com a arte enviada
- tela inicial de login com logo centralizada
- tela de progresso simplificada:
  - por padrão mostra apenas mensagens amigáveis
  - URLs e códigos internos ficam ocultos
  - botão `DETALHES` ativa o modo técnico


## Identidade visual — versão 1.4

Aplicada a identidade MASTER XCLOUD em toda a interface:
- fundo preto/grafite
- destaques laranja e azul-ciano
- botão principal em gradiente
- cartões com bordas discretas
- inputs com visual premium
- cabeçalho com linha de brilho laranja → azul
- logo na tela principal
- área de status em cartão próprio
- status resumidos com cores da marca
- modo técnico preservado pelo botão DETALHES


## Hotfix — versão 1.4.1

Corrigida uma quebra de linha inválida em uma string Java do modo DETALHES,
que impedia a compilação da versão 1.4.


## MASTER XCLOUD 1.5

- Uma única mensagem de status por vez.
- Mensagens amigáveis: Ativando MAC, Subindo M3U, Repondo DNS, Excluindo MAC.
- Após sucesso, limpa Device Key/MAC e URL M3U/DNS automaticamente.
- Login persistente reforçado:
  - reaproveita sessão/cookies quando possível;
  - reloga automaticamente com credenciais criptografadas salvas;
  - mais seletores e maior tempo de espera;
  - retry automático na rota direta de login.


## MASTER XCLOUD 1.5.1

Hotfix de compilação:
- corrigida uma quebra de linha inválida em string Java do modo DETALHES;
- mantidas todas as melhorias da 1.5:
  - uma única mensagem de status por vez;
  - limpeza automática de MAC e M3U/DNS após sucesso;
  - login persistente reforçado.


## MASTER XCLOUD 1.6

- O botão `PAINEL` agora sempre abre o dashboard principal do XCloud:
  `https://panel.xtream.cloud/dashboard`
- Funciona antes ou depois de qualquer automação.
- Não reaproveita mais a última tela de `Devices` ou `Custom Playlist`.
- Abrir o painel manualmente não inicia nenhuma automação.


## MASTER XCLOUD 1.7

Melhorias para uso diário sem novos botões na tela principal:

- `PAINEL` continua como regra fixa:
  sempre carrega `https://panel.xtream.cloud/dashboard`.
- `RESUMO` agora mostra:
  - sessão conectada;
  - versão instalada;
  - quantidade de operações do dia;
  - sucessos e falhas;
  - últimas 10 operações.
- histórico local com até 50 registros seguros:
  - data/hora;
  - MAC/Device Key;
  - tipo da operação;
  - resultado;
  - sem senha e sem M3U/DNS completo.
- confirmação antes de:
  - Editar (Reset) + DNS;
  - Excluir MAC.
- até 3 tentativas automáticas em falhas transitórias do painel.
- indicador `● Conectado`.
- histórico é preservado ao sair; `SAIR` apaga apenas credenciais/cookies.


## MASTER XCLOUD 1.7.1

Hotfix de compilação:
- removida a dependência de `BuildConfig.VERSION_NAME` no RESUMO;
- a versão instalada agora é obtida diretamente pelo PackageManager;
- mantidas todas as funções da v1.7;
- PAINEL continua sempre direcionando para o dashboard principal.


## MASTER XCLOUD 1.7.2

- O aplicativo não faz mais login automaticamente ao abrir.
- E-mail e senha continuam salvos/preenchidos.
- O login só é executado quando o usuário toca em `ENTRAR`.
- Mantidas todas as funções da v1.7.1.
- O botão `PAINEL` continua sempre abrindo o dashboard principal.


## MASTER XCLOUD 1.7.3

- Adicionado gesto **puxar para baixo para atualizar** nas duas telas:
  - tela principal da automação;
  - tela do PAINEL.
- Na tela principal, o gesto atualiza a sessão/painel em segundo plano.
- Dentro do PAINEL, o gesto recarrega a página visível.
- Se a sessão estiver expirada, o app volta para o login e aguarda o toque em `ENTRAR`.
- Mantido o login manual da v1.7.2.
- `PAINEL` continua sempre abrindo o dashboard principal.
